package expencive.vk.com.recipes.util;

public class Constants {

    public static final String BASE_URL = "https://www.food2fork.com";
    public static final String API_KEY = "e6e81685e105eb03edb4336f27d3ee60";
}
